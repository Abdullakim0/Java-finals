import java.util.ArrayList;
import java.util.Scanner;




public class MainBeta2 {

    public static int compare(String a) {
        return switch (a) {
            case "SIX" -> 6;
            case "SEVEN" -> 7;
            case "EIGHT" -> 8;
            case "NINE" -> 9;
            case "TEN" -> 10;
            case "JACK" -> 11;
            case "QUEEN" -> 12;
            case "KING" -> 13;
            case "ACE" -> 14;
            default -> 0;
        };
    }

    public static void endGame(ArrayList<?> playerList, ArrayList<?> botList) {
        if(playerList.isEmpty()){
            System.out.println("Player won, congratulation!!!");
            System.exit(0);
        }
        else if(botList.isEmpty()){
            System.out.println("Unfortunately, bot won(");
            System.exit(0);
        }
    }

    public static void info(ArrayList<?> playerList, ArrayList<?> botList, Deck deck){
        System.out.println(" ");
        System.out.println(" ");
        System.out.println("The cards were given");
        System.out.println(playerList+" "+playerList.size());
        System.out.println(botList+" "+botList.size());

        System.out.println("\n" + deck.size()+" cards left on the deck");
    }

    public static String choice(ArrayList<String> list) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Choose a card to throw: ");
        int index = Integer.parseInt(scanner.nextLine());
        String a = list.remove(index - 1);
        list.trimToSize();
        return a;

    }

    public static void main(String[] args) {


        ArrayList<String> bot=new ArrayList<>();
        ArrayList<String> list=new ArrayList<>();
        Deck deck = new Deck();

        System.out.println("Deck size: " + deck.size());

        for (int i = 0; i < 6; i++) {
            Card card = deck.drawCard();
            list.add(String.valueOf(card));

        }
        System.out.println(list + "    ");


        for(int i = 0; i < 6; i++) {
            Card card = deck.drawCard();
            bot.add(String.valueOf(card));

        }

        System.out.println(bot + "    ");
        System.out.println("\n" + deck.size()+" cards left on the deck");

        while(list.isEmpty() || !bot.isEmpty()){

            boolean Turn=true;
            while(Turn){
                endGame(list,bot);
                String a = choice(list);
                System.out.println("Player threw: "+a);
                String[] words=a.split("\\s+");//
                boolean found=false;//
                String w=words[1];//
                String n=words[0];//
                int n1 = compare(n);//

                int i,nv;
                for(i = 0; i < bot.size(); i++){
                    String element = bot.get(i);
                    if(element.contains(w)){

                        String[] Bwords=element.split("\\s+");
                        String v=Bwords[0];
                        nv = compare(v);
                        if(nv>n1){
                            found = true;
                            break;
                        }

                    }

                }
                if(deck.size()>0 && list.size()<6){ //
                    Card card = deck.drawCard();//
                    list.add(String.valueOf(card));//
                }//
                if (found) {
                    System.out.println("Bot bit with: "+bot.get(i));
                    bot.remove(i);
                    bot.trimToSize();
                    if(bot.size()<6 && deck.size()>0){
                        Card card1 = deck.drawCard();
                        bot.add(String.valueOf(card1));
                    }
                    Turn=false;

                } else {
                    bot.add(a);
                    System.out.println("Bot couldn't beat and took: "+a);

                }


                info(list,bot,deck);

            }



            while(!Turn){
                endGame(list,bot);
                String p;
                p = bot.remove(0);
                bot.trimToSize();
                System.out.println("Bot threw: "+p);
                String a = choice(list);
                String[] words=p.split("\\s+");//
                boolean match=false;//
                String w=words[1];//
                String n=words[0];//
                int n1 = compare(n);//
                int nv=0;
                if(a.contains(w)){
                    match = true;
                    String[] Bwords=a.split("\\s+");
                    String v=Bwords[0];
                    nv = compare(v);



                }
                if(deck.size()>0 && bot.size()<6){//
                    Card card = deck.drawCard();//
                    bot.add(String.valueOf(card));//
                }//

                if(match && nv>n1){
                    System.out.println("Player bit with: "+a);
                    if(list.size()<6 && deck.size()>0){
                        Card card1 = deck.drawCard();
                        list.add(String.valueOf(card1));
                    }
                    Turn=true;
                }
                else{
                    list.add(a);
                    list.add(p);
                    System.out.println("Player couldn't beat and took: "+p);

                }
                info(list,bot,deck);

            }
        }
    }
}
