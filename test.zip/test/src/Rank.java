public enum Rank {
    SIX, SEVEN, EIGHT, NINE, TEN, JACK, QUEEN, KING, ACE;


}

