public class Choice{
    static public int change(int a, int b){
        int c;
        c=a;
        a=b;
        b=c;
        return a;
    }
}